const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createChinaEvidenceService, formatChinaEvidence, extractLinks } = require('./chinaEvidence');

test('five sources keep query results, manual portals and policy guidance separate', async () => {
  const calls = [];
  const service = createChinaEvidenceService({ async get(url, options) {
    calls.push({ url, options });
    if (url.includes('nhsa')) return { data: { rows: [
      { registeredProductName: '测试药片', goodsCode: 'X001', productInsuranceType: '甲类' },
      { registeredProductName: '复方测试药片', goodsCode: 'WRONG' }
    ] } };
    if (url.includes('hainan')) return { data: '<html><a href="./guide.html">临床急需进口药品申报指南</a></html>' };
    return { data: '<html><a href="./notice.html">测试药片安全警示</a><a href="https://other.test/">测试药片广告</a></html>' };
  } });
  const item = { genericNameCn: '测试药片', brandName: 'Test', profile: 'PRIVATE', chatHistory: ['PRIVATE'] };
  const [sources] = await Promise.all([service.getChinaEvidence('drug', item), service.getChinaEvidence('drug', item)]);
  assert.equal(sources.length, 5); assert.equal(calls.length, 3);
  assert.deepEqual(sources.map(s => s.status), ['manual', 'matched', 'manual', 'guidance', 'matched']);
  assert.equal(sources[1].records.length, 1); assert.equal(sources[4].records.length, 1);
  assert.ok(!JSON.stringify(calls).includes('PRIVATE'));
  assert.ok(calls.every(c => !c.url.includes('nmpa') && !c.url.includes('chinamedreg')));
  const prompt = formatChinaEvidence(sources);
  assert.ok(prompt.includes('编码收录不等于医保报销'));
  assert.ok(prompt.includes('manual/unavailable/not_matched 均不是否定结论'));
});

test('verification challenges and upstream failures never become negative medical conclusions', async () => {
  const service = createChinaEvidenceService({ async get(url) {
    if (url.includes('nhsa')) return { data: { code: 9001, rows: 'verification script' } };
    throw new Error('timeout');
  } });
  const sources = await service.getChinaEvidence('drug', { genericNameCn: '测试药' });
  assert.equal(sources[1].status, 'manual');
  assert.equal(sources[3].status, 'unavailable');
  assert.equal(sources[4].status, 'unavailable');
  assert.ok(sources.every(s => !s.records));
});

test('trial uses only named interventions; unsafe links and unrelated records are excluded', async () => {
  let query;
  const service = createChinaEvidenceService({ async get(url, options) {
    if (url.includes('nhsa')) { query = options.params; return { data: { rows: [{ registeredProductName: '另一种药' }] } }; }
    return { data: '<html><a href="javascript:alert(1)">测试药</a></html>' };
  } });
  const sources = await service.getChinaEvidence('trial', { nctId: 'NCT00000001', interventionNames: ['测试药'], title: 'PRIVATE', summary: 'PRIVATE' });
  assert.equal(query.registeredProductName, '测试药');
  assert.equal(sources[1].status, 'not_matched');
  assert.deepEqual(extractLinks('<a href="http://localhost/">测试药</a>', 'https://www.cdr-adr.org.cn/', () => true), []);
});
